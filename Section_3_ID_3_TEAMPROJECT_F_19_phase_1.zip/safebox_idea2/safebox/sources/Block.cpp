#include "Block.h"
using namespace CryptoPP;
Block::Block(uint32_t p_block_size)
{
    block_size = p_block_size;
    read_size = 0;
    buffer = (char *)calloc(block_size + 1 + (block_size - (block_size % CryptoPP::AES::BLOCKSIZE)), sizeof(char));
}
bool Block::load(std::fstream &f)
{ 
    if (f.is_open())
    {         
        f.read(buffer, block_size);
        read_size = f.gcount(); 
        if (f || f.gcount() > 0)
            return true;
        else
            return false;
    }
    else
        return false;
}
bool Block::store(std::fstream &f)
{
    if (f.is_open())
    {
        f.write(buffer, read_size);
        return true;
    }
    else
        return false;
}
// we used different ideas in the block, so let's begin with the easiest part. 
void Block::encrypt(byte *key,byte *iv)
{ std::string ciphertext, encod; // String to take from string sink

/*while(read_size%block_size!=0){
   strcat(buffer," ");
    read_size++;    

}*/
//buffer = (char*) realloc(buffer, sizeof(char)*read_size);
//std::cout<<iv<<std::endl;
//std::cout<<key<<std::endl;
read_size = block_size;  // READ the read_size to be equal to block_size
      CryptoPP::AES::Encryption obj_aes(key,CryptoPP::AES::DEFAULT_KEYLENGTH); // I need to call the constructor of 
      //AES putting its key and length.
        CryptoPP::CBC_Mode_ExternalCipher::Encryption obj_cbc( obj_aes, iv );// I need to call the constructor of CBC MODE 
        //Inside it the AES and Intialization Vector
        //What I know is that It takes for stringSource, then STreamTransformationFilter takes it to move it to the sink.
        CryptoPP::StreamTransformationFilter st(obj_cbc, new CryptoPP::StringSink(ciphertext));//,CryptoPP::StreamTransformationFilter::ZEROS_PADDING);
       //A StreamTransformationFilter allows a symmetric cipher to participate in pipelining.
       // The filter also handles details such as padding.  
        st.Put(reinterpret_cast<const unsigned char*>(buffer),read_size); // Assuring to the filter that buffer will take 
        //the ciphertext
               st.MessageEnd(); // Fianlising everything for decryption.
      //StringSource(ciphertext, true, new HexEncoder(new StringSink(encod)));
        memcpy(buffer,ciphertext.c_str(),ciphertext.size());// Cpy what is_inside the ciphertext to buffer.In other words, 
        // Buffer will say, " I am ready to take the ciphertext".
            //    std::cout << buffer << std::endl; 

          read_size= ciphertext.size(); //Dont forget, resize needs to be the size of ciphertext.

          //Why do we do so? Because of the problem of padding(explained it in the shred Manager Comments).
}
void Block::decrypt(byte *key, byte *iv)
{    
 
//std::cout<<iv<<std::endl;
//std::cout<<key<<std::endl;
  std::string decryptedtext;  // I need a string to put inside it the decrypted ciphered text!
     CryptoPP::AES::Decryption obj_aes(key, CryptoPP::AES::DEFAULT_KEYLENGTH);// Same in the encrypted but this class decryption
        CryptoPP::CBC_Mode_ExternalCipher::Decryption obj_cbc( obj_aes, iv );// Same in the encrypted but this class decryption
     CryptoPP::StreamTransformationFilter st(obj_cbc, new CryptoPP::StringSink(decryptedtext));//CryptoPP::StreamTransformationFilter::ZEROS_PADDING);
        st.Put(reinterpret_cast<const unsigned char*>(buffer),read_size); // Make the buffer ready to take the text.
                 //std::cout<<decryptedtext<<std::endl;
                                   st.MessageEnd();// Finalizing everything
                  read_size = (uint16_t) decryptedtext.size(); // The size must be equatl to dedcrypted to make sure that 
                  // No errors will happen (less number of array elements)
                    memcpy(buffer,decryptedtext.c_str(),read_size);
                     
}
void Block::print()
{
   std::cout << buffer;
}
Block::~Block()
{
    if (buffer != NULL)
        free(buffer);
}
