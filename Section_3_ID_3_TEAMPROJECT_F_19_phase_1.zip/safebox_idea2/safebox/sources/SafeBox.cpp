#include <SafeBox.h>

SafeBox::SafeBox()
{
}
SafeBox::~SafeBox()
{
}
SafeBoxImport::SafeBoxImport()
{
}
//This is like the main functions. 
//I need to call functions
void SafeBoxImport::process(char *input_file,
                            char *output_file,
                            char *working_dir,
                            char *key_file,
                            uint16_t block_size,
                            uint16_t shreds)
{
    printf("Import file\n");
    //Simply, What I have done is that I need to contacetnate to be work_dir/output_file.
    // and with iv_file work_dir/iv_file
char iv_file[1024];
memset(iv_file,0,1024);
    strcpy(iv_file,working_dir);
    strcat(iv_file,"/");
    strcat(iv_file,"iv.txt");
strcat(working_dir,"/"); 
strcat(working_dir,output_file);
    ShredManager new_manager(working_dir,block_size, shreds ,true);//Calling the Shred Manager its constructors to send the path
    //I will write in the commands.
    FileSpooler New_file(input_file,block_size, false); //Then I need the file spooler to put it
    new_manager.encrypt(&New_file,key_file,iv_file);// in the parameter of the function of encrypt to encrypt.

}
SafeBox *SafeBoxImport::clone()
{
    return new SafeBoxImport();
}
SafeBoxImport::~SafeBoxImport()
{
}

SafeBoxExport::SafeBoxExport()
{
}
void SafeBoxExport::process(char *input_file,
                            char *output_file,
                            char *working_dir,
                            char *key_file,
                            uint16_t block_size,
                            uint16_t shreds)
{
char iv_file[1024]; // Same, 1024 to be maximum 
    printf("Export file\n"); 
memset(iv_file,0,1024);// Intialize all of them with zeros
    strcpy(iv_file,working_dir);// put the whole working dir inside iv file
    strcat(iv_file,"/");//conectenate to be workdir/
    strcat(iv_file,"iv.txt");//to be workdir/iv.txt
    strcat(working_dir,"/"); //workingdir/
    strcat(working_dir,input_file);// Put the inputfile
    ShredManager new_manager(working_dir,block_size, shreds ,false); // Calling the function new_managerbFalse for decryption
    // To make the shred size larger
     FileSpooler New_file(output_file,block_size, true); //Spooler is the same, but to append the decrypted blocks in one file
    new_manager.decrypt(&New_file,key_file,iv_file);// Here to decrypt.


}
SafeBox *SafeBoxExport::clone()
{
    return new SafeBoxExport();
}
SafeBoxExport::~SafeBoxExport()
{
}
