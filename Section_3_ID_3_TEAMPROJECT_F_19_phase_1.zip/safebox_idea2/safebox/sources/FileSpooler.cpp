#include <FileSpooler.h>
using namespace std; 
FileSpooler::FileSpooler(const char *p_file_name, uint16_t p_block_size, bool truncate)
{
    if (truncate)
        f.open(p_file_name, ios::in | ios::out | ios::trunc);
    else
        f.open(p_file_name, ios::in | ios::out);
    block_size = p_block_size;
}
Block *FileSpooler::getNextBlock()
{ // In this function I will make if condition. 
     Block* a = new Block(block_size); 
if(a->load(f))return a;
//If it loads return the block to give it to the shreds[i] in the shred Manager
else
{// Return null to close the loop: to make it finite
    delete (a);
    return NULL;
}

}
void FileSpooler::appendBlock(Block *b)
{
    b->store(f);
}

FileSpooler::~FileSpooler()
{
    if (f.is_open())
        f.close();
}
