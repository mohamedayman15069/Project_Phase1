#include "Block.h"
using namespace CryptoPP;
Block::Block(uint32_t p_block_size)
{
    block_size = p_block_size;
    read_size = 0;
    buffer = (char *)calloc(block_size + 1 + (block_size - (block_size % CryptoPP::AES::BLOCKSIZE)), sizeof(char));
}
bool Block::load(std::fstream &f)
{ 
    if (f.is_open())
    {         
        f.read(buffer, block_size);
        read_size = f.gcount(); 
        if (f || f.gcount() > 0)
            return true;
        else
            return false;
    }
    else
        return false;
}
bool Block::store(std::fstream &f)
{
    if (f.is_open())
    {
        f.write(buffer, read_size);
        return true;
    }
    else
        return false;
}

void Block::encrypt(byte *key,byte *iv)
{ std::string ciphertext, encod;

while(read_size%block_size!=0){ //This is while loop to handle the padding by ourselves. 
   strcat(buffer," ");// Extend the buffer 
    read_size++;    // Read the size

}
//buffer = (char*) realloc(buffer, sizeof(char)*read_size);
//std::cout<<iv<<std::endl;
//std::cout<<key<<std::endl;
      CryptoPP::AES::Encryption obj_aes(key,CryptoPP::AES::DEFAULT_KEYLENGTH); 
      // I need to call the constructor of 
      //AES putting its key and length.
        CryptoPP::CBC_Mode_ExternalCipher::Encryption obj_cbc( obj_aes, iv );
        //Inside it the AES and Intialization Vector
        //What I know is that It takes for stringSource, then STreamTransformationFilter takes it to move it to the sink.
        CryptoPP::StreamTransformationFilter st(obj_cbc, new CryptoPP::StringSink(ciphertext),CryptoPP::StreamTransformationFilter::ZEROS_PADDING);
       //A StreamTransformationFilter allows a symmetric cipher to participate in pipelining.
       // The filter also handles details such as padding.  
       // I need also to mention ZEROS_PADDING not to do padding.
        st.Put(reinterpret_cast<const unsigned char*>(buffer),strlen(buffer));
        // Assuring to the filter that buffer will take 
        //the ciphertext
               st.MessageEnd(); // Fianlising everything for decryption.
        //StringSource(ciphertext, true, new HexEncoder(new StringSink(encod)));
        
        memmove(buffer,ciphertext.c_str(),read_size); //To make sure that overloading will not happen.
}
void Block::decrypt(byte *key, byte *iv)
{    
 
//std::cout<<iv<<std::endl;
//std::cout<<key<<std::endl;
  std::string decryptedtext; 
     CryptoPP::AES::Decryption obj_aes(key, CryptoPP::AES::DEFAULT_KEYLENGTH);// Same in the encrypted but this class decryption
     // I need a string to put inside it the decrypted ciphered text!
        CryptoPP::CBC_Mode_ExternalCipher::Decryption obj_cbc( obj_aes, iv );// Same in the encrypted but this class decryption
     CryptoPP::StreamTransformationFilter st(obj_cbc, new CryptoPP::StringSink(decryptedtext),CryptoPP::StreamTransformationFilter::ZEROS_PADDING);
      // Make the buffer ready to take the text.
        st.Put(reinterpret_cast<const unsigned char*>(buffer),read_size);// Finalizing everything
       // std::cout << strlen(buffer)<< std::endl; 
               //  std::cout<<decryptedtext<<std::endl;
                  st.MessageEnd();
                  // The size must be equatl to dedcrypted to make sure that 
                  // No errors will happen (less number of array elements)
                    memmove(buffer,decryptedtext.c_str(),read_size);
                     
}
void Block::print()
{
   std::cout << buffer;
}
Block::~Block()
{
    if (buffer != NULL)
        free(buffer);
}
