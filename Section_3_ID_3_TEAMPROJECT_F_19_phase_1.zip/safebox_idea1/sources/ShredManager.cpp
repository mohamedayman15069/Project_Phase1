 #include <ShredManager.h>
using namespace CryptoPP; 
ShredManager::ShredManager(char *p_file_name, uint16_t p_block_size, uint16_t p_shred_count, bool truncate)
{
    shred_count = p_shred_count;
    shreds = (Shred **)calloc(shred_count, sizeof(Shred *));
    for (char i = 0; i < shred_count; i++)
    {
    std::string outputfilename=p_file_name;
    outputfilename.insert(outputfilename.find('.'), 1, 'A'+i);
    // This will help us to shreds. I mean that this line will make 
    // ....A.txt the second one B.txt, so A+i will go to the second one from A to B to C and so on depending to the number of shreds.
    // To conclude, this will find the '.' to the inputfile name.txt and replace before it A or B.
    //outputfilename+=i;
    	if(truncate){
            // This condition will help me in encrpytion and decryption.
            // This is when I need to encrypt.
        shreds[i] = new Shred(outputfilename.c_str(),p_block_size,truncate);
    }else{
        // This is when I need to decrypt, the difference is the outblocked for some reason which is padding problem.
    // so when encrypting, the last block is of course not a multiple of the all blocks, so during encryption, 
    // it padds the last block. 
    //To make the decryption process understanding this padding, I am using this assignment.(p_block_size+16)&~15)
    	//uint16_t outblocksize= (p_block_size+16)&~15;
        shreds[i] = new Shred(outputfilename.c_str(),p_block_size/*+16)&~15*/,truncate);
	}
    }
}
bool ShredManager::encrypt(FileSpooler *fileSpooler, const char *key_file_name, const char *iv_file_name)
{
        // In general, I need to open the key file and iv file.

 std::ifstream key_file; 
 key_file.open(key_file_name,std::ios::in);
 byte *key= new byte[CryptoPP::AES::DEFAULT_KEYLENGTH]; 
            key_file.read(reinterpret_cast< char*>(key),CryptoPP::AES::DEFAULT_KEYLENGTH);//Putting it in the heap, and after that I need to cast the key to be able 
 std::cout<<key<<std::endl;
 // to read from the Key_file.

 std::ofstream iv_file; 
 iv_file.open(iv_file_name,std::ios::out);// I need to write the generated random iv in a file
         AutoSeededRandomPool iv_random;
            byte* iv= new byte[AES::BLOCKSIZE]; // This class "AutoSeededRandomPool" will help us to generate random bytes.
           iv_random.GenerateBlock(iv,sizeof(iv));// It will be equal to block size
        iv_file.write(reinterpret_cast< char*>(iv),sizeof(iv));// I need to generate the random in iv.
          std::cout<<iv<<std::endl;

            Block * b= fileSpooler->getNextBlock();
// I need to declare the block b to perform the coming loop. 
// It says that I will take each block and encrypt it, after that appending.
    for ( int i = 0 ; b != NULL ; i++)
    {   
        b->encrypt(key,iv);//Encrypting the (i+1)th block
        *(shreds[i%shred_count])<< *(b);// This appending will happen with the condition that i%shredcount. 
        //It means that put the block in a specific shred. Finally, when you reach the final shred. 
        //come back to the first one and so on.
        delete(b);
        b = fileSpooler->getNextBlock();
    // After finishing , I need to load the coming block.
    }
    delete(iv);
    delete (key);
    return true;

}
bool ShredManager::decrypt(FileSpooler *fileSpooler, const char *key_file_name, const char *iv_file_name)
{ // I need to decrypt the shreds 
std::ifstream key_file;
std::ifstream iv_file; 
 byte* iv= new byte[AES::BLOCKSIZE]; 
// Open then the generated iv from seededrandom pool.

 byte *key= new byte[CryptoPP::AES::DEFAULT_KEYLENGTH]; 
key_file.open(key_file_name,std::ios::in);
//Open also the key file to decrypt.

 key_file.read(reinterpret_cast< char*>(key), CryptoPP::AES::DEFAULT_KEYLENGTH);
 iv_file.open(iv_file_name,std::ios::in);
 iv_file.read(reinterpret_cast< char*>(iv), AES::BLOCKSIZE );
 Block* b = shreds[0]->getNextBlock();
// I need to get the first block
//std::cout << iv << std:: endl; 
for (int i = 1; b != NULL; i++)
{      // This for loop will help me to decrypt each block and then appending it in a file.
 b->decrypt(key,iv);
 fileSpooler->appendBlock(b);
delete(b); 
b = shreds[i%shred_count]->getNextBlock() ;// The same concept as in encrypt to take all blocks from the shreds. Arriving at the last one,
//come back to the first one.
}
delete(iv);
    delete (key);
    return false;
}
ShredManager::~ShredManager()
{
    for (int i = 0; i < shred_count; i++)
        delete (shreds[i]);
    free(shreds);
}
