#ifndef BLOCK_H
#define BLOCK_H

#include <defines.h>
#include <includes.h>
#include <iostream>
#include <fstream>
#include<string.h>
#include <string.h>
#include <stdio.h>
#include "crypto++/cryptlib.h"
#include "crypto++/modes.h"
#include "crypto++/filters.h"
#include "crypto++/aes.h"
#include "crypto++/osrng.h"
#include "crypto++/strciphr.h"



class Block {

    private:
        uint32_t block_size;
        uint32_t read_size;
        char * buffer;
    public:

        Block (uint32_t p_block_size);
        bool load(std::fstream & f);
        bool store(std::fstream & f);
        void encrypt(byte * key, byte * iv);
        void decrypt(byte * key, byte * iv);
        void print ();
        ~Block();
};
#endif
